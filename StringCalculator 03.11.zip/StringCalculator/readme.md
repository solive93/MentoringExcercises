# Castellers Kata

### This Kata was proposed by people from ThoughtWorks in Barcelona, who came* recurrently every week/15 days to Factoria F5's Bootcamp to give us a masterclass about different topics such as Git, TDD, Refactoring, Legacy Code, CI/CD, Docker. We did this kata with them.

