<?php
namespace App;

final class stringCalculator 
{
    public function add($test){
        $test = 0;
        return $test;
    
    }
    
}